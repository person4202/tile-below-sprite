# Tile Below Sprite – MakeCode Arcade Extension

This extension adds a block that returns the **tile location directly below a sprite**.  
You can use it with `tiles.setTileAt(...)`, `tiles.setWallAt(...)`, etc.

### Example

```ts
tiles.setTileAt(myBlocks.tileBelow(mySprite), assets.tile`myTile`)
```

### Block Preview

`tile below (sprite)`

---

## Installation
1. Create a GitHub repo with these files.
2. In [MakeCode Arcade](https://arcade.makecode.com/), click **Import → Extension**.
3. Paste your repo link.
